#!/usr/bin/env python3
"""
SQLBot 启动脚本
简化版的 Text-to-SQL 服务
"""

import os
import sys
from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import pymssql
import json
from dotenv import load_dotenv

# 加载环境变量
load_dotenv('config/.env')

app = Flask(__name__)
CORS(app)

# 数据库配置
DB_CONFIG = {
    'server': os.getenv('DB_HOST', '47.115.38.118'),
    'port': int(os.getenv('DB_PORT', 9024)),
    'database': os.getenv('DB_NAME', 'GW_Course'),
    'user': os.getenv('DB_USER', 'gw_reader'),
    'password': os.getenv('DB_PASSWORD', ''),
    'charset': 'utf8'
}

# 简单的 HTML 模板
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQLBot - 智能问数系统</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .query-box { margin-bottom: 20px; }
        .query-box textarea { width: 100%; height: 100px; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        .query-box button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .result { margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px; }
        .sql-code { background: #e9ecef; padding: 10px; border-radius: 3px; font-family: monospace; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; }
        .success { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 SQLBot - 智能问数系统</h1>
        <p>输入自然语言查询，系统将自动生成 SQL 并执行</p>
        <p><small>数据源：GW_Course 数据库 (与 GW.Trackr 共享)</small></p>
    </div>
    
    <div class="query-box">
        <textarea id="queryInput" placeholder="例如：查询最近一个月的新增用户数量"></textarea>
        <br><br>
        <button onclick="executeQuery()">🔍 执行查询</button>
    </div>
    
    <div id="result" class="result" style="display: none;"></div>
    
    <script>
        async function executeQuery() {
            const query = document.getElementById('queryInput').value;
            const resultDiv = document.getElementById('result');
            
            if (!query.trim()) {
                alert('请输入查询内容');
                return;
            }
            
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>🔄 正在处理查询...</p>';
            
            try {
                const response = await fetch('/api/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: query })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    resultDiv.className = 'result success';
                    resultDiv.innerHTML = `
                        <h3>✅ 查询成功</h3>
                        <div class="sql-code"><strong>生成的 SQL：</strong><br>${data.sql}</div>
                        <div><strong>查询结果：</strong></div>
                        <pre>${JSON.stringify(data.data, null, 2)}</pre>
                    `;
                } else {
                    resultDiv.className = 'result error';
                    resultDiv.innerHTML = `<h3>❌ 查询失败</h3><p>${data.error}</p>`;
                }
            } catch (error) {
                resultDiv.className = 'result error';
                resultDiv.innerHTML = `<h3>❌ 网络错误</h3><p>${error.message}</p>`;
            }
        }
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/query', methods=['POST'])
def query():
    try:
        data = request.get_json()
        user_query = data.get('query', '')
        
        # 简单的查询映射（实际项目中应该使用 AI 模型）
        sql_mapping = {
            '用户': 'SELECT COUNT(*) as user_count FROM Consumer',
            '学员': 'SELECT COUNT(*) as student_count FROM Consumer WHERE ConsumerType = \'学员\'',
            '课程': 'SELECT COUNT(*) as course_count FROM Course',
            '最近': 'SELECT TOP 10 * FROM Consumer ORDER BY CreateTime DESC'
        }
        
        # 简单匹配生成 SQL
        sql = None
        for keyword, query_sql in sql_mapping.items():
            if keyword in user_query:
                sql = query_sql
                break
        
        if not sql:
            sql = 'SELECT TOP 5 ConsumerName, Phone, CreateTime FROM Consumer ORDER BY CreateTime DESC'
        
        # 执行查询
        conn = pymssql.connect(**DB_CONFIG)
        cursor = conn.cursor(as_dict=True)
        cursor.execute(sql)
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'sql': sql,
            'data': results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'service': 'SQLBot'})

if __name__ == '__main__':
    port = int(os.getenv('PORT', 8002))
    print(f"🚀 SQLBot 启动在端口 {port}")
    print(f"🌐 访问地址: http://localhost:{port}")
    print(f"📊 数据库: {DB_CONFIG['database']} @ {DB_CONFIG['server']}:{DB_CONFIG['port']}")
    app.run(host='0.0.0.0', port=port, debug=False)
